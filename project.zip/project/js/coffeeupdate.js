$(document).ready(function () {
    $('#new').click(function() {
        alert("April: Matcha Green Tea Latte\nMay: Rose and Cardamom Latte\nJune: Peach Iced Tea")
    });
});